package club.itsuki.study

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private val startUrl = "https://itsukistudyclub.com/"

    // выбор файлов
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val fileRequestCode = 1001

    // полноэкранное видео
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var fullscreenContainer: FrameLayout? = null

    // подстройка цвета полос под фон страницы
    private val handler = Handler(Looper.getMainLooper())
    private var currentColor = 0

    private val colorJs = """
        (function(){try{
          var e=document.body,b=e?getComputedStyle(e).backgroundColor:'';
          if(!b||b==='rgba(0, 0, 0, 0)'||b==='transparent'){b=getComputedStyle(document.documentElement).backgroundColor;}
          var c=document.createElement('canvas');c.width=c.height=1;
          var x=c.getContext('2d');x.fillStyle=b;x.fillRect(0,0,1,1);
          var d=x.getImageData(0,0,1,1).data;
          return d[0]+','+d[1]+','+d[2]+','+d[3];
        }catch(err){return '';}})()
    """.trimIndent()

    private val poll = object : Runnable {
        override fun run() {
            if (customView == null) {
                web.evaluateJavascript(colorJs) { raw ->
                    val p = raw?.trim('"')?.split(",")?.mapNotNull { it.trim().toIntOrNull() }
                    if (p != null && p.size == 4 && p[3] > 0) applyBarColor(Color.rgb(p[0], p[1], p[2]))
                }
            }
            handler.postDelayed(this, 800)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        // Цвет последней открытой страницы — чтобы при запуске не было чёрных/белых вспышек
        val night = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val startColor = getSharedPreferences("app", MODE_PRIVATE)
            .getInt("bg", if (night) 0xFF111111.toInt() else 0xFFFFFFFF.toInt())

        root = FrameLayout(this)
        web = WebView(this)
        root.addView(web, match())

        setContentView(root)
        applyBarColor(startColor)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                WindowInsetsCompat.Type.displayCutout() or
                WindowInsetsCompat.Type.ime()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }

        web.webChromeClient = object : WebChromeClient() {

            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val multiple = params.mode == FileChooserParams.MODE_OPEN_MULTIPLE

                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Добавить")
                    .setItems(arrayOf("Галерея", "Файлы")) { _, which ->
                        val ok = try {
                            if (which == 0) startGallery(multiple)
                            else { startActivityForResult(params.createIntent(), fileRequestCode); true }
                        } catch (e: ActivityNotFoundException) { false }
                        if (!ok) cancelChooser()
                    }
                    .setOnCancelListener { cancelChooser() }
                    .show()
                return true
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customCallback = callback
                val container = FrameLayout(this@MainActivity).apply {
                    setBackgroundColor(Color.BLACK)
                    addView(view, match())
                }
                fullscreenContainer = container
                setContentView(container)
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                setSystemBarsVisible(false)
            }

            override fun onHideCustomView() {
                val view = customView ?: return
                fullscreenContainer?.removeView(view)
                fullscreenContainer = null
                customView = null
                customCallback?.onCustomViewHidden()
                customCallback = null
                setContentView(root)
                ViewCompat.requestApplyInsets(root)
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                setSystemBarsVisible(true)
                applyBarColor(currentColor)
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val host = request.url.host ?: return false
                if (host == "itsukistudyclub.com" || host.endsWith(".itsukistudyclub.com")) return false
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(request.url.toString())))
                return true
            }
        }

        if (savedInstanceState != null) web.restoreState(savedInstanceState) else web.loadUrl(startUrl)
    }

    private fun match() =
        FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

    // Красим фон под панелями и значки статус-бара в цвет страницы
    private fun applyBarColor(color: Int) {
        if (color == currentColor) return
        currentColor = color
        root.setBackgroundColor(color)
        window.setBackgroundDrawable(ColorDrawable(color))
        val lum = (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.isAppearanceLightStatusBars = lum > 0.5
        c.isAppearanceLightNavigationBars = lum > 0.5
        getSharedPreferences("app", MODE_PRIVATE).edit().putInt("bg", color).apply()
    }

    private fun setSystemBarsVisible(visible: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (visible) c.show(WindowInsetsCompat.Type.systemBars())
        else c.hide(WindowInsetsCompat.Type.systemBars())
    }

    // Галерея: системный выбор фото (Android 13+) или обычная галерея
    private fun startGallery(multiple: Boolean): Boolean {
        return try {
            val i = if (Build.VERSION.SDK_INT >= 33) {
                Intent(MediaStore.ACTION_PICK_IMAGES).apply {
                    type = "image/*"
                    if (multiple) putExtra(MediaStore.EXTRA_PICK_IMAGES_MAX, 10)
                }
            } else {
                Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply {
                    type = "image/*"
                    if (multiple) putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
            }
            startActivityForResult(i, fileRequestCode)
            true
        } catch (e: ActivityNotFoundException) {
            try {
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    if (multiple) putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                startActivityForResult(i, fileRequestCode)
                true
            } catch (e2: ActivityNotFoundException) {
                false
            }
        }
    }

    private fun cancelChooser() {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = null
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(poll)
        handler.post(poll)
    }

    override fun onPause() {
        handler.removeCallbacks(poll)
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && customView != null) setSystemBarsVisible(false)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == fileRequestCode) {
            filePathCallback?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            )
            filePathCallback = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> web.webChromeClient?.onHideCustomView()
            web.canGoBack() -> web.goBack()
            else -> super.onBackPressed()
        }
    }
}
